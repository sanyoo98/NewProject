﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Button3.Enabled = false;
            Button4.Enabled = false;
            Button5.Enabled = false;
            Button6.Enabled = false;
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Enabled = true;
            TextBox2.Enabled = true;
            TextBox3.Enabled = true;
            TextBox4.Enabled = true;
            Button1.Enabled = false;
            Button2.Enabled = false;
            Button3.Enabled = true;
            Button6.Enabled = true;
            Button1.Enabled = false;
            Label7.Text = "New Blank Form Has Been Added.";
            Label8.Text = "";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            String query = "insert into studs(rollno,name,contact,email) values(" + TextBox1.Text + ",'" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
            String mycon = "Data Source=LAPTOP-TCPGBEA4\\SQLEXPRESS; Initial Catalog=CMS; Integrated Security=true";
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = query;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            Button1.Enabled = true;
            Button2.Enabled = true;
            Button6.Enabled = false;
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;
            Label7.Text = "Data Has Been Saved Successfully";
            Label8.Text = "";

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Button1.Enabled = true;
            Button2.Enabled = true;
            Button3.Enabled = false;
            Button4.Enabled = false;
            Button5.Enabled = false;
            Button6.Enabled = false;
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;
            Label7.Text = "Operation Has Been Cancelled Successfully";
            Label8.Text = "";

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String mycon = "Data Source=LAPTOP-TCPGBEA4\\SQLEXPRESS; Initial Catalog=CMS; Integrated Security=true";
            String myquery = "Select * from studs where rollno=" + TextBox1.Text;
            SqlConnection con = new SqlConnection(mycon);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = myquery;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Label8.Text = "Roll Number Found Successfully";
                Label7.Text = "";
                TextBox2.Text = ds.Tables[0].Rows[0]["name"].ToString();
                TextBox3.Text = ds.Tables[0].Rows[0]["contact"].ToString();
                TextBox4.Text = ds.Tables[0].Rows[0]["email"].ToString();
                Button4.Enabled = true;
                Button5.Enabled = true;
                Button6.Enabled = true;
                TextBox2.Enabled = true;
                TextBox3.Enabled = true;
                TextBox4.Enabled = true;
                Button2.Enabled = false;
            }
            else
            {
                Label8.Text = "No Particular Searched Roll Number Found";
                Label7.Text = "";

            }
            con.Close();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            String mycon = "Data Source=LAPTOP-TCPGBEA4\\SQLEXPRESS; Initial Catalog=CMS; Integrated Security=True";
            String updatedata = "Update studs set name='" + TextBox2.Text + "', contact='" + TextBox3.Text + "', email='" + TextBox4.Text + "' where rollno=" + TextBox1.Text;
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            Label8.Text = "";
            Label7.Text = "Particular Record Has Been Updated Successfully : Roll Number " + TextBox1.Text;
            Button1.Enabled = true;
            Button2.Enabled = true;
            Button3.Enabled = false;
            Button4.Enabled = false;
            Button5.Enabled = false;
            Button6.Enabled = false;
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            String mycon = "Data Source=LAPTOP-TCPGBEA4\\SQLEXPRESS; Initial Catalog=CMS; Integrated Security=True";
            String updatedata = "delete from studs where rollno=" + TextBox1.Text;
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            Label8.Text = "";
            Label7.Text = "Particular Record Has Been Deleted Successfully : Roll Number " + TextBox1.Text;
            Button1.Enabled = true;
            Button2.Enabled = true;
            Button3.Enabled = false;
            Button4.Enabled = false;
            Button5.Enabled = false;
            Button6.Enabled = false;
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;

        }
    }
}